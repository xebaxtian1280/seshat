L'Arche de la Défense by Kegira
https://3dwarehouse.sketchup.com/model/659b962c0c2cb9ab64cbaf8bce068c60/LArche-de-la-D%C3%A9fense