Panthéon de Paris by Little-Goomba
https://3dwarehouse.sketchup.com/model/4768178c265d78738167aec7f5633c33/Panth%C3%A9on-de-Paris